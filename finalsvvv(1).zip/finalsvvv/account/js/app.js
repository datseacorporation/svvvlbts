(function(){

  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyCOSBHeMFDXjySmxBDL_9HNZMLve3wtc28",
    authDomain: "datseacorporation-33b34.firebaseapp.com",
    databaseURL: "https://datseacorporation-33b34.firebaseio.com",
    projectId: "datseacorporation-33b34",
    storageBucket: "datseacorporation-33b34.appspot.com",
    messagingSenderId: "34583842624"
  };
  firebase.initializeApp(config);

  const loginEmail = document.getElementById('loginEmail');
  const loginPassword = document.getElementById('loginPassword');
  const loginButton = document.getElementById('loginButton');
  const resetPassbutton = document.getElementById('resetPassbutton');



  loginButton.addEventListener('click', e => {

const email = loginEmail.value;
const pass = loginPassword.value;
const auth = firebase.auth();

const promise = auth.signInWithEmailAndPassword(email, pass);
promise.catch(e => console.log(e.message));

});

window.onload = function doLoginFun() {
$("#logintweak").show();
$("#loginPassword").show();
$("#resetPasstweak").hide();
$("#loginButton").show();
$("#resetPassbutton").hide();
$("#backtologlink").hide();
$("#forgotpasswordLink").show();
}

function runtimebacktoLog() {
  $("#logintweak").show();
  $("#loginPassword").show();
  $("#resetPasstweak").hide();
  $("#loginButton").show();
  $("#resetPassbutton").hide();
  $("#backtologlink").hide();
  $("#forgotpasswordLink").show();
}
function doResetPassFun() {
$("#resetPasstweak").show();
$("#logintweak").hide();
$("#loginPassword").hide();
$("#loginButton").hide();
$("#resetPassbutton").show();
$("#backtologlink").show();
$("#forgotpasswordLink").hide();
}

function sendMailto() {
  const resetMailtoEmail =loginEmail.value;
  var auth = firebase.auth();
  var emailAddress = resetMailtoEmail;

  auth.sendPasswordResetEmail(emailAddress).then(function() {
    console.log("Mail Sent OK !");
    alert("Please open this : "+emailAddress+" Mail Account, We Have Just Sent Reset Link !");
    runtimebacktoLog();
  }).catch(function(error) {
    // An error happened.
    console.log("Mail Not Sent !");
  });
}
resetPassbutton.addEventListener('click', e => {
sendMailto();
});
forgotpasswordLink.addEventListener('click', e => {
doResetPassFun();
});
backtologlink.addEventListener('click', e => {
runtimebacktoLog();
});

firebase.auth().onAuthStateChanged(firebaseUser => {
  if (firebaseUser) {
    console.log(firebaseUser);
      window.location = '../index.html';

  } else {
    console.log('Not Logged In');

  }
});

}());
