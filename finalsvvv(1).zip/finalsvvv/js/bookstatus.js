(function(){
var config = {
  apiKey: "AIzaSyCOSBHeMFDXjySmxBDL_9HNZMLve3wtc28",
  authDomain: "datseacorporation-33b34.firebaseapp.com",
  databaseURL: "https://datseacorporation-33b34.firebaseio.com",
  projectId: "datseacorporation-33b34",
  storageBucket: "datseacorporation-33b34.appspot.com",
  messagingSenderId: "34583842624"
};
firebase.initializeApp(config);

firebase.auth().onAuthStateChanged(function(user) {
  console.log('authStateChanged', user);
  if (user) {
    console.log("Welcome UID:" + user.uid);

var firebaseRef = firebase.database().ref().child('BookRequest').child(user.uid);
firebaseRef.on("child_added", snap => {


var bookTitle = snap.child("titlenametxt").val();
var authorName = snap.child("authornametxt").val();
var publisherName = snap.child("publishernametxt").val();
var bookEdition = snap.child("bookeditiontxt").val();
var bookIsbn = snap.child("bookisbntxt").val();
var BookRequestdatetime = snap.child("bookRequestingdnt").val();
var bookStatus = snap.child("lblBookingstatus").val();

document.getElementById('lblBooktitle').innerHTML =  bookTitle;
document.getElementById("lblAuthorname").innerHTML = authorName;
document.getElementById("lblPublishername").innerHTML = publisherName;
document.getElementById("lblBookedition").innerHTML = bookEdition;
document.getElementById("lblBookisbn").innerHTML = bookIsbn;
document.getElementById("lbldatetime").innerHTML = BookRequestdatetime;
document.getElementById("lblBookingstatus").innerHTML = bookStatus;


});



}
});
}());
