window.onload = function what(){
  n =  new Date();
  y = n.getFullYear();
  m = n.getMonth() + 1;
  d = n.getDate();
//document.getElementById("bookRequestingdnt").innerHTML = d + "-" + m + "-" + y;
document.getElementById("datelabel").innerHTML = d + "-" + m + "-" + y;
console.log(d + "-" + m + "-" + y);
}
