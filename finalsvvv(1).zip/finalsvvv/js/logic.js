
 // Initialize Firebase
    var config = {
      apiKey: "AIzaSyCOSBHeMFDXjySmxBDL_9HNZMLve3wtc28",
      authDomain: "datseacorporation-33b34.firebaseapp.com",
      databaseURL: "https://datseacorporation-33b34.firebaseio.com",
      projectId: "datseacorporation-33b34",
      storageBucket: "datseacorporation-33b34.appspot.com",
      messagingSenderId: "34583842624"
    };
    firebase.initializeApp(config);


      const logoutButton = document.getElementById('logoutButton');
	  function logoutAlert() {
    var txt;
    if (confirm("Press a button!") == true) {
        firebase.auth().signOut();
		window.location = 'account/index.html';
    } else {

    }

}

logoutButton.addEventListener('click', e => {
logoutAlert();

});



firebase.auth().onAuthStateChanged(function(user) {
   console.log('authStateChanged', user);
   if (user) {
     console.log("Welcome UID:" + user.uid);
     var firebaseRef = firebase.database().ref().child('BookRequest').child(user.uid).push();

var d = new Date();
var dateInputtxt  = document.getElementById("bookRequestingdnt").value = d;
console.log("This it " + dateInputtxt);

     	  $('#submitrequestbtn').click (function(){
     	  firebaseRef.set({

     	  authornametxt:$('#authornametxt').val(),
     	  titlenametxt:$('#titlenametxt').val(),
     	  publishernametxt:$('#publishernametxt').val(),
           bookeditiontxt:$('#bookeditiontxt').val(),
     	  bookisbntxt:$('#bookisbntxt').val(),
        bookRequestingdnt:$('#bookRequestingdnt').val(),
		   lblBookingstatus:$('#lblBookingstatus').val()
     	  });
     	 });
   }

 });
