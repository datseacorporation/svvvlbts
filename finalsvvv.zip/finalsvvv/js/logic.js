 
 // Initialize Firebase
    var config = {
      apiKey: "AIzaSyCOSBHeMFDXjySmxBDL_9HNZMLve3wtc28",
      authDomain: "datseacorporation-33b34.firebaseapp.com",
      databaseURL: "https://datseacorporation-33b34.firebaseio.com",
      projectId: "datseacorporation-33b34",
      storageBucket: "datseacorporation-33b34.appspot.com",
      messagingSenderId: "34583842624"
    };
    firebase.initializeApp(config);

      const logoutButton = document.getElementById('logoutButton');
	  function logoutAlert() {
    var txt;
    if (confirm("Press a button!") == true) {
        firebase.auth().signOut();
		window.location = 'account/index.html';
    } else {

    }
    
}

logoutButton.addEventListener('click', e => {
logoutAlert();

});
	  
	  
   
      var firebaseRef = firebase.database().ref().push().child('BookRequest');
	  $('#submitrequestbtn').click (function(){
	  firebaseRef.set({
	  
	  authornametxt:$('#authornametxt').val(),
	  titlenametxt:$('#titlenametxt').val(),
	  publishernametxt:$('#publishernametxt').val(),
      bookeditiontxt:$('#bookeditiontxt').val(),
	  bookisbntxt:$('#bookisbntxt').val()
	  });
	 });
	  
