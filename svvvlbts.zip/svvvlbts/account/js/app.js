(function(){

  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyCOSBHeMFDXjySmxBDL_9HNZMLve3wtc28",
    authDomain: "datseacorporation-33b34.firebaseapp.com",
    databaseURL: "https://datseacorporation-33b34.firebaseio.com",
    projectId: "datseacorporation-33b34",
    storageBucket: "datseacorporation-33b34.appspot.com",
    messagingSenderId: "34583842624"
  };
  firebase.initializeApp(config);

  const loginEmail = document.getElementById('loginEmail');
  const loginPassword = document.getElementById('loginPassword');
  const loginButton = document.getElementById('loginButton');
  const logoutButton = document.getElementById('logoutButton');


  loginButton.addEventListener('click', e => {

const email = loginEmail.value;
const pass = loginPassword.value;
const auth = firebase.auth();

const promise = auth.signInWithEmailAndPassword(email, pass);
promise.catch(e => console.log(e.message));

});

function logoutAlert() {
    var txt;
    if (confirm("Press a button!") == true) {
        firebase.auth().signOut();
    } else {

    }
    document.getElementById("demo").innerHTML = txt;
}

logoutButton.addEventListener('click', e => {
logoutAlert();
//window.location = 'index.html';
});

firebase.auth().onAuthStateChanged(firebaseUser => {
  if (firebaseUser) {
    console.log(firebaseUser);
      $("#loginEmail").hide();
        $("#loginPassword").hide();
    $("#loginButton").hide();
      $("#registerLink").hide();
  //  window.location = 'index.html';
  } else {
    console.log('Not Logged In');
      $("#logoutButton").hide();
      $("#loginEmail").show();
        $("#loginPassword").show();
        $("#registerLink").show();
  }
});

}());
