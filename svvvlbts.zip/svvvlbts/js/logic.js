 
 // Initialize Firebase
    var config = {
      apiKey: "AIzaSyCOSBHeMFDXjySmxBDL_9HNZMLve3wtc28",
      authDomain: "datseacorporation-33b34.firebaseapp.com",
      databaseURL: "https://datseacorporation-33b34.firebaseio.com",
      projectId: "datseacorporation-33b34",
      storageBucket: "datseacorporation-33b34.appspot.com",
      messagingSenderId: "34583842624"
    };
    firebase.initializeApp(config);

   
      var firebaseRef = firebase.database().ref().push().child('BookRequest');
	  $('#submitrequestbtn').click (function(){
	  firebaseRef.set({
	  
	  authornametxt:$('#authornametxt').val(),
	  titlenametxt:$('#titlenametxt').val(),
	  publishernametxt:$('#publishernametxt').val(),
      bookeditiontxt:$('#bookeditiontxt').val(),
	  bookisbntxt:$('#bookisbntxt').val()
	  });
	 });
	  
